# Clean Davis-style height and weight data
#
# Removes rows with missing values in required columns and filters clearly
# unrealistic height and weight values.
#
# @param data A data frame containing weight, height, repwt, and repht columns.
# @return A cleaned data frame.
# @export
clean_davis <- function(data) {
  required_cols <- c("weight", "height", "repwt", "repht")

  if (!all(required_cols %in% names(data))) {
    stop("Data must contain weight, height, repwt, and repht columns.")
  }

  cleaned <- data |>
    dplyr::filter(!is.na(weight), !is.na(height), !is.na(repwt), !is.na(repht)) |>
    dplyr::filter(height >= 120, height <= 230) |>
    dplyr::filter(repht >= 120, repht <= 230) |>
    dplyr::filter(weight >= 35, weight <= 200) |>
    dplyr::filter(repwt >= 35, repwt <= 200)

  cleaned
}

# Plot reported versus measured weight
#
# Creates an improved scatterplot with a 45-degree reference line and BMI color scale.
#
# @param data A data frame that includes repwt, weight, and bmi.
# @return A ggplot object.
# @export
plot_comparison <- function(data) {
  needed <- c("repwt", "weight", "bmi")

  if (!all(needed %in% names(data))) {
    stop("Data must contain repwt, weight, and bmi columns. Run calc_bmi() first.")
  }

  ggplot2::ggplot(data, ggplot2::aes(x = repwt, y = weight, color = bmi)) +
    ggplot2::geom_abline(intercept = 0, slope = 1, linetype = "dashed", linewidth = 0.8) +
    ggplot2::geom_point(size = 3, alpha = 0.85) +
    ggplot2::scale_color_gradient(low = "skyblue3", high = "firebrick2") +
    ggplot2::labs(
      title = "Reported vs Measured Weight",
      subtitle = "Points near the dashed line indicate more accurate self-reporting",
      x = "Reported Weight (kg)",
      y = "Measured Weight (kg)",
      color = "BMI"
    ) +
    ggplot2::theme_minimal(base_size = 13) +
    ggplot2::theme(
      plot.title = ggplot2::element_text(face = "bold"),
      panel.grid.minor = ggplot2::element_blank()
    )
}

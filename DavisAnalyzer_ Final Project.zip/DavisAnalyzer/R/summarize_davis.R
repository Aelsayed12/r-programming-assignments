# Summarize Davis-style body measurement data
#
# Produces key averages for measured values, BMI, and reporting error.
#
# @param data A data frame that includes bmi, weight_error, and height_error.
# @return A one-row data frame of summary statistics.
# @export
summarize_davis <- function(data) {
  needed <- c("height", "weight", "bmi", "weight_error", "height_error")

  if (!all(needed %in% names(data))) {
    stop("Run calc_bmi() first so bmi and error columns exist.")
  }

  data.frame(
    mean_height = round(mean(data$height, na.rm = TRUE), 2),
    mean_weight = round(mean(data$weight, na.rm = TRUE), 2),
    mean_bmi = round(mean(data$bmi, na.rm = TRUE), 2),
    mean_weight_error = round(mean(data$weight_error, na.rm = TRUE), 2),
    mean_height_error = round(mean(data$height_error, na.rm = TRUE), 2),
    correlation_rep_measured_weight = round(stats::cor(data$repwt, data$weight, use = "complete.obs"), 3)
  )
}

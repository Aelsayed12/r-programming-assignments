# Calculate BMI and reporting error fields
#
# Adds BMI and difference variables comparing self-reported and measured values.
#
# @param data A cleaned data frame.
# @return A data frame with bmi, weight_error, and height_error columns added.
# @export
calc_bmi <- function(data) {
  if (!all(c("weight", "height", "repwt", "repht") %in% names(data))) {
    stop("Data must contain weight, height, repwt, and repht columns.")
  }

  data |>
    dplyr::mutate(
      bmi = weight / (height / 100)^2,
      weight_error = repwt - weight,
      height_error = repht - height
    )
}

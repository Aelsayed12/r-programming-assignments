# DavisAnalyzer

DavisAnalyzer is an R package for cleaning, summarizing, and visualizing differences between self-reported and measured height and weight data. The project uses a Davis-style dataset to explore reporting error and body mass index patterns.

## Features

- Cleans missing and unrealistic values
- Calculates BMI from measured height and weight
- Summarizes reporting error and body metrics
- Produces an improved ggplot comparison figure

## Folder Structure

```
DavisAnalyzer/
├── DESCRIPTION
├── NAMESPACE
├── README.md
├── R/
├── data/
├── man/
└── blog_post.md
```

## Example Usage

```r
library(DavisAnalyzer)

davis <- read.csv("data/davis.csv")
davis_clean <- clean_davis(davis)
davis_bmi <- calc_bmi(davis_clean)
summarize_davis(davis_bmi)
plot_comparison(davis_bmi)
```

## Project Goal

This package was designed to make a simple dataset more reusable while showing how package structure, documentation, and function design work together in a complete R project.

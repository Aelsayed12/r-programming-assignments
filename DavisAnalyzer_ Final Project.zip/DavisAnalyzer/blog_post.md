# Building DavisAnalyzer: An R Package for Studying Self-Reported Height and Weight Data

## Introduction

For my final project, I built an R package called **DavisAnalyzer**. The goal of this package is to clean, summarize, and visualize a dataset that contains both self-reported and measured height and weight values. I selected this topic because it connects directly to a practical issue in data analysis: self-reported data is easy to collect, but it is not always perfectly accurate. That makes it a useful example for studying data quality, reporting bias, and reproducible analysis.

Rather than submitting a single script, I organized this work as a proper R package with a DESCRIPTION file, separate folders for code, data, and documentation, and a GitHub-ready structure. This approach made the project more realistic and showed how reusable analysis tools can be packaged for future use.

## Why I Chose This Topic

I wanted a topic that was simple enough to manage in one semester project, but still interesting from an analytical point of view. The Davis-style dataset was a strong choice because it includes measured height and weight along with self-reported height and weight. That means the project can go beyond basic summaries and instead examine where people overestimate or underestimate their own measurements.

I also wanted to avoid repeating the most common classroom examples without adding anything new. Many students choose `mtcars`, which is a useful dataset, but I wanted a project with a more original focus. This dataset gave me a chance to build something that combines cleaning, transformation, and visualization in a way that is easy to explain and useful to demonstrate in a blog post.

## Project Goals

The main goals of the package were: 

1. Create a function that cleans the data and removes missing or unrealistic values.
2. Create a function that calculates BMI from measured height and weight.
3. Create a function that summarizes key metrics in one table.
4. Create a polished visualization comparing reported and measured weight.
5. Organize everything using standard R package structure so it can be uploaded to GitHub.

These goals helped keep the package focused. Instead of trying to do too much, I built a small set of clear functions that work together as a simple analysis pipeline.

## Package Structure

I structured the project as a standard R package. The root folder contains the `DESCRIPTION` file, `NAMESPACE`, and `README.md`. The `R` folder contains the source code for each function, with one function per file. The `data` folder contains the dataset in CSV format. The `man` folder contains an R Markdown documentation file that explains how the package works and demonstrates the full workflow.

This structure is important because it separates responsibilities clearly. Source code stays in one place, documentation stays in another, and the package becomes easier to maintain and understand. It also reflects how real R packages are organized rather than how class assignments are often submitted as one long script.

## Function Design

### `clean_davis()`

The first function in the package removes rows with missing values in the main measurement columns and filters out clearly unrealistic values. This step matters because bad input data can distort summary statistics and visualizations. I set reasonable bounds for height and weight so that obvious outliers or invalid entries do not remain in the cleaned dataset.

### `calc_bmi()`

The second function calculates body mass index using the measured weight and height variables. In addition to BMI, it also creates two helpful variables: `weight_error` and `height_error`. These measure the difference between the self-reported and measured values. That allows the package to capture reporting bias directly rather than only looking at raw values.

### `summarize_davis()`

The third function produces a one-row summary table with the mean height, mean weight, mean BMI, mean weight reporting error, mean height reporting error, and the correlation between reported and measured weight. I designed it this way so the user can quickly see the major patterns in the dataset without having to write multiple summary commands manually.

### `plot_comparison()`

The final function creates an improved ggplot scatterplot of reported weight against measured weight. I made the plot more informative by adding a dashed 45-degree reference line, which represents perfect agreement between self-report and measurement. I also used BMI as the color scale so that the plot communicates an additional variable without becoming too cluttered. The minimal theme helps the plot look cleaner and more submission-ready.

## Visual Improvements

One of the biggest improvements I made was in the plotting function. A plain scatterplot would technically work, but it would not communicate the pattern as clearly. By including the diagonal reference line, the viewer can immediately judge whether a point reflects accurate self-reporting or not. Points above or below the line show misreporting.

Coloring the points by BMI adds another layer of insight. It allows the viewer to see whether reporting accuracy may vary across different body profiles. Even if the package does not make a strong causal claim, this visual choice helps the chart tell a more complete story. I also adjusted the point size, transparency, subtitle, and theme to make the figure easier to read and more professional-looking.

## Challenges I Faced

One challenge in this project was deciding how much functionality to include. It can be tempting to add many features, but that often makes a package less focused. I decided it was better to create four functions that are clear and reliable instead of building too many functions with overlapping purposes.

Another challenge was documentation. Writing code is one part of the work, but packaging it for reuse requires explanation. I needed to think about what another user would need to understand the functions, the data, and the sequence of steps. That is why the documentation file and this blog post were important parts of the project rather than afterthoughts.

A third challenge was improving the visual design without making it overly complicated. I wanted the ggplot output to be noticeably stronger than a default chart while still being easy to understand for someone reading the blog or reviewing the code.

## Use of AI in This Project

AI was used in this project as a support tool, not as a replacement for my own work. Specifically, AI helped with brainstorming package structure, drafting starter code, and suggesting ways to improve the clarity of the plotting function and written explanations. AI was also useful for checking whether the project matched the assignment requirements.

However, I independently chose the project topic, selected the dataset direction, decided on the package goals, revised the functions, shaped the final documentation, and edited the blog content into its final form. I also made the final decisions about package organization, function purpose, and how the analysis should be presented in a human-readable way.

## What I Learned

This project helped me understand that building an R package is not just about writing functions. It is also about organization, communication, and reproducibility. A package forces you to think about what the user needs, how the code should be divided logically, and how documentation supports the overall project.

I also learned that even a relatively small dataset can support meaningful analysis if the project is designed carefully. By focusing on self-reported versus measured values, I was able to build a package that demonstrates cleaning, feature creation, summary analysis, and visualization in one coherent workflow.

Finally, I learned that presentation matters. A clear structure, readable documentation, and a visually improved plot make the project easier to understand and more persuasive as an example of completed work.

## Conclusion

Overall, `DavisAnalyzer` is a compact but complete example of an R package project. It takes a Davis-style dataset and turns it into a reusable workflow for cleaning data, computing BMI, summarizing patterns, and visualizing reporting accuracy. The package meets the assignment requirements by including a DESCRIPTION file, organized folders, documentation, GitHub-ready structure, and a blog that explains the process in a human-readable way.

This project showed me how package development can turn a basic data analysis task into a more professional and reusable tool. It also reinforced the importance of combining technical work with explanation, reflection, and transparency about the role of AI in the development process.

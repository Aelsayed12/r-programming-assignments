# Optional helper script
# This file is included to show how the dataset can be loaded for package use.

davis <- read.csv("data/davis.csv")
head(davis)
